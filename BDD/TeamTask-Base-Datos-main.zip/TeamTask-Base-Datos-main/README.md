# TeamTask: Base de datos
> Repositorio de codigo de bases de datos
> ## Ramas del proyecto:
> - Stored Procedure (Bazan-Fabiano)
> - Functions (Delia-Scrocca)
> - Triggers (Martin-Zwaig)
> - Testing (Varas)
# Formato de Archivos
> Al subir un archivo en su correspondiente rama, deberan subir un archivo SQL  que tenga como nombre de la entidad a la que corresponden, Un ejemplo podria ser el siguiente:
> `Usuario.sql`
# Accesos directos
> - [`Store Procedure`](https://github.com/TeamTaskerUB/TeamTask-Base-Datos/tree/main/Procedure)
> - [`Functions`](https://github.com/TeamTaskerUB/TeamTask-Base-Datos/tree/main/Procedure)
> - [`Triggers`](https://github.com/TeamTaskerUB/TeamTask-Base-Datos/tree/main/Triggers)
